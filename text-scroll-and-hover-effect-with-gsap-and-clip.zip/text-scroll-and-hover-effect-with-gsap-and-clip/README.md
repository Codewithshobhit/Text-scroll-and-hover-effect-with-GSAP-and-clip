# Text scroll and hover effect with GSAP and clip

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/VwRvbYy](https://codepen.io/Codewithshobhit/pen/VwRvbYy).

